# Bootstrap-промпт #3: Telegram-шлюз (опционально)

**Когда использовать:** скармливаешь Claude Code этим промптом, ТОЛЬКО если
хочешь чат-режим через Telegram (как Jarvis у меня). После Промпта #1+2
агент уже работает в shell -- этот промпт навешивает Telegram-канал.

**Без шлюза агент = `claude` в терминале.** Со шлюзом = чат в TG, в который
оператор пишет сообщение, а Claude Code на сервере отвечает.

---

# ЗАДАЧА

Развернуть FastAPI/aiohttp-шлюз, который:
1. Принимает webhook'и от Telegram Bot API
2. Запускает Claude Code (`claude`) как subprocess в нужном workspace
3. Стримит ответ обратно в Telegram (с typing-индикаторами)
4. Поддерживает: text, голос (Whisper транскрибация), файлы, изображения
5. Имеет allowlist по user_id (никто кроме оператора не пишет агенту)
6. Запускается через systemd, перезапускается при падении

В plan mode сначала покажи план: какие файлы нужны, как развернуть, что
запросить у оператора. После "yes" -- разворачивай.

---

# 1. ПРЕДУСЛОВИЯ ОТ ОПЕРАТОРА

- [ ] Telegram bot token (через @BotFather: `/newbot`, получить токен)
- [ ] Свой Telegram user_id (узнать у @userinfobot или @getmyid_bot)
- [ ] (опц) Groq API key для голосовых -- через [console.groq.com](https://console.groq.com)
- [ ] Python 3.10+ установлен (`python3 --version`)

---

# 2. ВАРИАНТЫ РАЗВЁРТЫВАНИЯ

## Вариант A -- свой минимальный шлюз с нуля (~200 строк)

Подходит если хочется простую штуку без лишних фич. Только text + голос +
allowlist.

## Вариант B -- готовый шлюз claude-gateway

У оператора уже есть рабочий шлюз `~/claude-gateway/` (137KB Python,
многоагентный, с поддержкой topic-routing, Firebase auth, OpenViking
streaming). Если хочется ту же машину -- копируй.

**Если репо публичное** -- `git clone <url>` в `~/claude-gateway-new/`.
**Если приватное** -- оператор делает `tar czf` и переносит вручную.

В этом промпте описываю **Вариант A** (минимальный с нуля) -- если нужен
Вариант B, уточни у оператора путь к существующему `claude-gateway/`.

---

# 3. ВАРИАНТ A: МИНИМАЛЬНЫЙ ШЛЮЗ (рекомендую для старта)

## 3.1 Структура

```
~/agent-gateway/
├── gateway.py              # ~200 строк main loop
├── config.json             # token, allowlist, workspace path
├── requirements.txt        # python-telegram-bot, aiofiles
├── secrets/                # mode 700
│   └── tg-bot-token        # mode 600
└── .venv/                  # Python virtualenv
```

## 3.2 `requirements.txt`

```
python-telegram-bot>=21.0
aiofiles>=23.0
httpx>=0.27.0
```

## 3.3 `config.json`

```json
{
  "_comment": "Minimal Claude Code Telegram gateway",
  "telegram_bot_token_file": "~/agent-gateway/secrets/tg-bot-token",
  "allowlist_user_ids": [<TELEGRAM_USER_ID_OF_OPERATOR>],
  "workspace": "~/agent/.claude",
  "claude_binary": "/usr/local/bin/claude",
  "model": "sonnet",
  "effort": "medium",
  "timeout_sec": 600,
  "groq_api_key_file": "~/agent-gateway/secrets/groq-api-key",
  "system_reminder": "Ты общаешься с оператором через Telegram. Отвечай по сути, без воды."
}
```

## 3.4 `gateway.py` (минимальная версия, ~150 строк)

```python
#!/usr/bin/env python3
"""Minimal Telegram → Claude Code gateway."""
import asyncio
import json
import os
import subprocess
import sys
from pathlib import Path
from telegram import Update
from telegram.ext import (
    Application, CommandHandler, MessageHandler, ContextTypes, filters
)

CONFIG_PATH = Path(__file__).parent / "config.json"
CONFIG = json.loads(CONFIG_PATH.read_text())

def expand(p: str) -> str:
    return os.path.expanduser(p)

TOKEN = Path(expand(CONFIG["telegram_bot_token_file"])).read_text().strip()
ALLOW = set(CONFIG["allowlist_user_ids"])
WS = expand(CONFIG["workspace"])
CLAUDE = CONFIG.get("claude_binary", "claude")
MODEL = CONFIG.get("model", "sonnet")
EFFORT = CONFIG.get("effort", "medium")
TIMEOUT = CONFIG.get("timeout_sec", 600)
SYS_REMINDER = CONFIG.get("system_reminder", "")

async def is_allowed(update: Update) -> bool:
    return update.effective_user and update.effective_user.id in ALLOW

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if not await is_allowed(update):
        return
    await update.message.reply_text("Готов. Пиши что нужно сделать.")

async def transcribe_voice(file_path: Path) -> str:
    """Transcribe via Groq Whisper if key available, else return placeholder."""
    key_file = expand(CONFIG.get("groq_api_key_file", ""))
    if not key_file or not Path(key_file).exists():
        return "[голосовое сообщение -- Groq API key не настроен]"
    import httpx
    key = Path(key_file).read_text().strip()
    async with httpx.AsyncClient(timeout=60) as cli:
        with file_path.open("rb") as f:
            r = await cli.post(
                "https://api.groq.com/openai/v1/audio/transcriptions",
                headers={"Authorization": f"Bearer {key}"},
                files={"file": (file_path.name, f, "audio/ogg")},
                data={"model": "whisper-large-v3", "language": "ru"},
            )
        r.raise_for_status()
        return r.json()["text"]

async def handle_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if not await is_allowed(update):
        return
    msg = update.message
    text = msg.text or msg.caption or ""

    # Voice transcription
    if msg.voice or msg.audio:
        file = await ctx.bot.get_file((msg.voice or msg.audio).file_id)
        local = Path(f"/tmp/voice_{msg.message_id}.ogg")
        await file.download_to_drive(custom_path=str(local))
        text = await transcribe_voice(local)
        local.unlink(missing_ok=True)
        await msg.reply_text(f"[голос]: {text}")

    if not text:
        await msg.reply_text("Пустое сообщение, пропускаю")
        return

    # Send typing indicator
    await ctx.bot.send_chat_action(msg.chat_id, "typing")

    # Build prompt
    full_prompt = f"{SYS_REMINDER}\n\n{text}" if SYS_REMINDER else text

    # Run claude binary
    cmd = [
        CLAUDE,
        "--workspace", WS,
        "--model", MODEL,
        "--effort", EFFORT,
        "--print",
        full_prompt,
    ]
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=TIMEOUT)
        out = stdout.decode("utf-8", errors="replace").strip()
        if not out:
            out = "[пустой ответ]"
            if stderr:
                out += f"\n\nstderr: {stderr.decode('utf-8', errors='replace')[:500]}"
    except asyncio.TimeoutError:
        out = f"[timeout после {TIMEOUT}s]"
    except Exception as e:
        out = f"[ошибка: {e}]"

    # Telegram limit -- 4096 chars per message
    for chunk in [out[i:i+4000] for i in range(0, len(out), 4000)]:
        await msg.reply_text(chunk)

def main() -> None:
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND | filters.VOICE | filters.AUDIO,
        handle_message,
    ))
    print("Gateway started", file=sys.stderr)
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
```

## 3.5 Установка

```bash
mkdir -p ~/agent-gateway/secrets
cd ~/agent-gateway
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Token (получи от @BotFather)
echo "<YOUR_BOT_TOKEN>" > ~/agent-gateway/secrets/tg-bot-token
chmod 600 ~/agent-gateway/secrets/tg-bot-token

# (опц) Groq key
echo "<YOUR_GROQ_KEY>" > ~/agent-gateway/secrets/groq-api-key
chmod 600 ~/agent-gateway/secrets/groq-api-key

chmod 700 ~/agent-gateway/secrets

# Тест запуска
python3 ~/agent-gateway/gateway.py
# В телеге -- /start, должен ответить "Готов"
# Стоп -- Ctrl+C
```

## 3.6 Systemd unit (`/etc/systemd/system/agent-gateway.service`)

```ini
[Unit]
Description=Claude Code Telegram Gateway
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=<OPERATOR_USERNAME>
Group=<OPERATOR_USERNAME>
WorkingDirectory=/home/<OPERATOR_USERNAME>/agent-gateway
ExecStart=/home/<OPERATOR_USERNAME>/agent-gateway/.venv/bin/python /home/<OPERATOR_USERNAME>/agent-gateway/gateway.py
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=agent-gateway
Environment=HOME=/home/<OPERATOR_USERNAME>
Environment=PATH=/home/<OPERATOR_USERNAME>/.local/bin:/usr/local/bin:/usr/bin:/bin

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now agent-gateway
sudo systemctl status agent-gateway
journalctl -u agent-gateway -f  # смотреть логи
```

---

# 4. ВАРИАНТ B: ГОТОВЫЙ CLAUDE-GATEWAY (если нужны продвинутые фичи)

Если хочется поддержку:
- Multi-agent (несколько Claude Code в одном шлюзе)
- Topic-routing в Telegram-группах
- Streaming (бот печатает по ходу как живой)
- Firebase service-account allowlist
- OpenViking semantic memory интеграция
- Полный media pipeline (фото/видео/документы)

Тогда:

1. **Получить от оператора** существующий `~/claude-gateway/` -- либо
   через `git clone`, либо `tar czf -C ~/claude-gateway . | ssh new-server "tar xzf - -C ~/claude-gateway/"`.
2. Адаптировать `config.json` под нового оператора:
   - заменить `allowlist_user_ids`, `agents.<name>.workspace`, `telegram_bot_token_file`
3. Создать секреты в `~/claude-gateway/secrets/`
4. Установить как systemd service (см. unit-файл из существующей установки)

Размер: 137KB исходника (`gateway.py`) + 6KB конфиг-пример.

---

# 5. ФИНАЛЬНАЯ ПРОВЕРКА

- [ ] `systemctl is-active agent-gateway` → `active`
- [ ] В Telegram пишешь `/start` боту -- получаешь "Готов"
- [ ] Пишешь "Привет, как дела?" -- бот отвечает (через Claude Code)
- [ ] Голосовое сообщение -- транскрибируется (если Groq key настроен)
- [ ] `journalctl -u agent-gateway -n 50` -- логи без ошибок
- [ ] Кто-то посторонний пишет боту -- НЕ получает ответа (allowlist работает)

---

# 6. ИЗВЕСТНЫЕ ОГРАНИЧЕНИЯ МИНИМАЛЬНОГО ВАРИАНТА A

- Нет streaming -- ответ приходит целиком после завершения Claude Code (~30-60 сек)
- Нет typing-индикатора по ходу работы
- Нет поддержки фото/видео в input'е
- Один агент = один бот (нет мульти-агентного маршрутизатора)

Для production-юзкейсов с долгими тасками -- расширь Variant A или
переходи на Variant B.

---

# 7. БЕЗОПАСНОСТЬ

- `allowlist_user_ids` -- ОБЯЗАТЕЛЕН. Без него любой может писать боту и
  гонять Claude Code на твоём сервере (=> деньги Anthropic, RCE-риски).
- Bot token хранить **только** в `secrets/` с `chmod 600`. Никогда в коде.
- Если бот скомпрометирован (token утёк) -- через @BotFather: `/revoke`,
  получить новый.
- Шлюз гоняет Claude Code от имени оператора (с его правами `sudo`!).
  Поэтому allowlist строжайше.
