# Bootstrap-промпт #2: реальный код cron-скриптов и референсных файлов

**Когда использовать:** скармливаешь Claude Code этим промптом ПОСЛЕ того, как
завершился Промпт #1 (структура файлов и SOUL созданы). Этот промпт
разворачивает реальные файлы:

- `core/AGENTS.md` (справочник агентов)
- `core/TOOLS.md` (справочник моделей/инструментов/MCP)
- 5 cron-скриптов ротации памяти
- `settings.local.json` (permissions allowlist)
- `crontab` (расписание ротаций)
- `.env` пример

---

# ЗАДАЧА

После Промпта #1 у нас есть структура `~/agent/.claude/` с `CLAUDE.md`,
`USER.md`, `rules.md` и пустыми `core/MEMORY.md`, `core/LEARNINGS.md`,
`core/warm/decisions.md`, `core/hot/handoff.md`. Сейчас наполняем
референсные файлы и автоматизацию памяти.

В plan mode сначала покажи план: какие файлы создашь, куда запишешь cron.
После моего "yes" -- создавай.

---

# 1. AGENTS.md (`~/agent/.claude/core/AGENTS.md`)

```markdown
# AGENTS.md -- Reference layer (Read tool, не в контексте)

Справочник других агентов. Читается по запросу через Read tool, не
подгружается в контекст автоматически. Обновляется руками.

## Текущие агенты

### <Имя агента> (например, Jarvis) -- я

- **Канал:** <Telegram через шлюз / shell / web>
- **Workspace:** `~/agent/.claude/`
- **Роль:** <короткое описание>
- **Модель:** Sonnet 4.6 (по умолчанию). Эскалация на Opus -- через `--effort high`.
- **Инициация:** не инициирую общение -- только отвечаю на триггеры.

## Координация между агентами

Если будут второй+ агенты -- описать здесь. Пример:

### Richard (server-doctor) [пример]

- **Канал:** ad-hoc через `claude` в shell
- **Workspace:** `~/.claude-lab/richard/.claude/`
- **Роль:** диагностика инфраструктуры
- **Модель:** Sonnet 4.6, без streaming

Связи между агентами:
1. Файлы памяти в `~/.claude-lab/shared/`
2. Через оператора
3. OpenViking (если развёрнут) -- через MCP

## Будущие агенты

Когда добавится новый -- блок по тому же шаблону.
```

---

# 2. TOOLS.md (`~/agent/.claude/core/TOOLS.md`)

```markdown
# TOOLS.md -- Reference layer (Read tool, не в контексте)

Справочник инструментов и моделей. Читается по запросу.

## Модели (Anthropic)

| Модель | Сильная сторона | Используется для |
|---|---|---|
| Sonnet 4.6 | Код, диалог, архитектура | Основной режим |
| Opus 4.7 | Сложная архитектура, второе мнение | Эскалация (3 strikes), ревью |
| Haiku 4.5 | Дёшево, быстро | Компрессия памяти |

## Базовые инструменты Claude Code

| Инструмент | Когда использовать |
|---|---|
| `Read` | Чтение конкретного файла |
| `Write` | Создание нового файла |
| `Edit` | Точечная правка существующего файла |
| `Glob` | Поиск файлов по паттерну |
| `Grep` | Поиск содержимого в файлах |
| `Bash` | Shell-команды |
| `Agent` | Запуск субагента (макс 3 параллельно) |
| `TodoWrite` | План задачи 3+ шагов |
| `WebFetch` | Скачать страницу |
| `WebSearch` | Поиск в сети |

## MCP-сервера

| Сервер | Что даёт | Конфиг |
|---|---|---|
| `n8n-mcp` | 1505 n8n-нод как справочник | через `claude mcp add` |
| `openviking-memory` (опц) | Долгосрочная семантическая память | `~/.claude.json` + Docker |

## Cron-ротации памяти (НЕ ломать структуру `core/`)

| Cron | Скрипт | Что делает |
|---|---|---|
| 04:30 | `rotate-warm.sh` | WARM >14 секций -> COLD |
| 05:00 | `trim-hot.sh` | recent.md/handoff.md по размеру/возрасту |
| 06:00 | `compress-warm.sh` | dedupe bullets в decisions.md |
| 06:30 | `ov-session-sync.sh` | hot+warm -> OpenViking (если включён) |
| 21:00 | `memory-rotate.sh` | MEMORY.md >5KB -> archive/YYYY-MM.md |

Скрипты в `~/agent/scripts/`. Парсят `## YYYY-MM-DD` заголовки.

## Внешние API (если используются)

| API | Назначение | Где ключ |
|---|---|---|
| Groq | Whisper-транскрибация | `~/agent/secrets/groq-api-key` |
| Perplexity | Web-research | через скилл |
| OpenAI | Эмбеддинги для OpenViking | `~/.openviking/ov.conf` |
```

---

# 3. CRON-СКРИПТЫ (`~/agent/scripts/`)

Создай папку `~/agent/scripts/` и пять скриптов. Все требуют переменную
`AGENT_WS=$HOME/agent/.claude` (либо в crontab, либо через дефолт в скрипте).

## 3.1 `rotate-warm.sh`

```bash
#!/usr/bin/env bash
# rotate-warm.sh -- move oldest sections from warm/decisions.md into cold/MEMORY.md.
# Runs daily at 04:30 via cron. No LLM calls, deterministic.
#
# Heuristic: if decisions.md has > 14 "## " sections, OLDEST section is appended
# to MEMORY.md and removed from decisions.md. Repeats until <= 14 sections.
set -euo pipefail

AGENT_WS="${AGENT_WS:-$HOME/agent/.claude}"
DECISIONS="$AGENT_WS/core/warm/decisions.md"
MEMORY="$AGENT_WS/core/MEMORY.md"
LOG_DIR="$HOME/agent/logs"
LOG_FILE="$LOG_DIR/memory-cron.log"

mkdir -p "$LOG_DIR"
log() { echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] [rotate-warm] $*" >> "$LOG_FILE" 2>/dev/null || true; }

[ -f "$DECISIONS" ] || { log "decisions.md missing"; exit 0; }
[ -f "$MEMORY" ] || printf '# MEMORY.md\n\nLong-term notes.\n' > "$MEMORY"

SECTIONS=$(grep -c '^## ' "$DECISIONS" 2>/dev/null || echo 0)
if [ "${SECTIONS:-0}" -le 14 ]; then log "ok (${SECTIONS} sections)"; exit 0; fi

python3 - "$DECISIONS" "$MEMORY" <<'PY'
import re, sys
dec, mem = sys.argv[1], sys.argv[2]
content = open(dec, encoding='utf-8').read()
sections = [(m.start(), m.group(0)) for m in re.finditer(r'^## .+$', content, re.MULTILINE)]
rotated = 0
while len(sections) > 14:
    start = sections[-1][0]
    text = content[start:]
    content = content[:start].rstrip() + "\n"
    with open(mem, 'a', encoding='utf-8') as f:
        f.write("\n---\n(rotated from decisions.md)\n" + text + "\n")
    rotated += 1
    sections = [(m.start(), m.group(0)) for m in re.finditer(r'^## .+$', content, re.MULTILINE)]
open(dec, 'w', encoding='utf-8').write(content)
print(f"rotated: {rotated}")
PY

log "rotate-warm complete"
```

## 3.2 `trim-hot.sh`

```bash
#!/usr/bin/env bash
# trim-hot.sh -- trim recent.md (size cap) and handoff.md (size + age).
# Runs daily at 05:00. No LLM calls.
set -euo pipefail

AGENT_WS="${AGENT_WS:-$HOME/agent/.claude}"
RECENT="$AGENT_WS/core/hot/recent.md"
HANDOFF="$AGENT_WS/core/hot/handoff.md"
LOG_DIR="$HOME/agent/logs"
LOG_FILE="$LOG_DIR/memory-cron.log"
mkdir -p "$LOG_DIR"
log() { echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] [trim-hot] $*" >> "$LOG_FILE" 2>/dev/null || true; }

# recent.md size cap (12KB, keep last 50 ### entries, min 10)
RECENT_LIMIT=12288
if [ -f "$RECENT" ]; then
    SIZE=$(wc -c < "$RECENT" | tr -d ' ')
    if [ "$SIZE" -gt "$RECENT_LIMIT" ]; then
        cp "$RECENT" "${RECENT}.pre-trim"
        python3 - "$RECENT" "$RECENT_LIMIT" <<'PY'
import re, sys
path, limit = sys.argv[1], int(sys.argv[2])
c = open(path, encoding='utf-8').read()
hm = re.match(r'^#[^#].*\n', c)
header = hm.group(0) if hm else "# Hot memory\n\n"
ents = list(re.finditer(r'^### ', c, re.MULTILINE))
if len(ents) > 50:
    c = header + "\n" + c[ents[-50].start():]
    ents = list(re.finditer(r'^### ', c, re.MULTILINE))
while len(c.encode('utf-8')) > limit and len(ents) > 10:
    c = header + "\n" + c[ents[1].start():]
    ents = list(re.finditer(r'^### ', c, re.MULTILINE))
open(path, 'w', encoding='utf-8').write(c)
PY
        log "recent.md trimmed from ${SIZE}B"
    fi
fi

# handoff.md staleness (>6h => placeholder) + size cap (4KB)
if [ -f "$HANDOFF" ]; then
    AGE=$(( ($(date +%s) - $(stat -c%Y "$HANDOFF" 2>/dev/null || echo 0)) / 3600 ))
    if [ "$AGE" -ge 6 ]; then
        cat > "$HANDOFF" <<STALE
# handoff.md -- last 10 entries (@include)

Previous session ended more than 6h ago. Context stale.
Start a fresh session: recall recent work from core/hot/recent.md if needed.
STALE
        log "handoff.md stale (${AGE}h), cleared"
    else
        SIZE=$(wc -c < "$HANDOFF" | tr -d ' ')
        if [ "$SIZE" -gt 4096 ]; then
            python3 - "$HANDOFF" 4096 <<'PY'
import sys
p, mx = sys.argv[1], int(sys.argv[2])
c = open(p, encoding='utf-8', errors='replace').read()
while len(c.encode('utf-8')) > mx: c = c[:-100]
nl = c.rfind('\n');  c = c[:nl] if nl>0 else c
open(p, 'w', encoding='utf-8').write(c)
PY
            log "handoff.md trimmed from ${SIZE}B"
        fi
    fi
fi
log "trim-hot complete"
```

## 3.3 `compress-warm.sh`

```bash
#!/usr/bin/env bash
# compress-warm.sh -- dedupe bullets and collapse blank lines in decisions.md.
# Runs daily at 06:00. No LLM calls.
set -euo pipefail

AGENT_WS="${AGENT_WS:-$HOME/agent/.claude}"
DECISIONS="$AGENT_WS/core/warm/decisions.md"
LOG_DIR="$HOME/agent/logs"
LOG_FILE="$LOG_DIR/memory-cron.log"
mkdir -p "$LOG_DIR"
log() { echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] [compress-warm] $*" >> "$LOG_FILE" 2>/dev/null || true; }

[ -f "$DECISIONS" ] || { log "missing"; exit 0; }
BEFORE=$(wc -c < "$DECISIONS" | tr -d ' ')

python3 - "$DECISIONS" <<'PY'
import re, sys
p = sys.argv[1]
c = open(p, encoding='utf-8').read()
secs = re.split(r'(?=^## )', c, flags=re.MULTILINE)
def dedupe(s):
    seen, out = set(), []
    for ln in s.split('\n'):
        st = ln.strip()
        if st.startswith(('- ','* ','+ ')) and st in seen: continue
        if st.startswith(('- ','* ','+ ')): seen.add(st)
        out.append(ln)
    return '\n'.join(out)
joined = ''.join(dedupe(s) if s.startswith('## ') else s for s in secs)
joined = re.sub(r'\n{3,}', '\n\n', joined)
open(p, 'w', encoding='utf-8').write(joined)
PY

AFTER=$(wc -c < "$DECISIONS" | tr -d ' ')
log "${BEFORE}B -> ${AFTER}B"
```

## 3.4 `memory-rotate.sh`

```bash
#!/usr/bin/env bash
# memory-rotate.sh -- archive cold memory when MEMORY.md > 5KB.
# Runs daily at 21:00. Keeps first 20 lines, rest -> archive/YYYY-MM.md.
set -euo pipefail

AGENT_WS="${AGENT_WS:-$HOME/agent/.claude}"
MEMORY="$AGENT_WS/core/MEMORY.md"
ARCHIVE_DIR="$AGENT_WS/core/archive"
LOG_DIR="$HOME/agent/logs"
LOG_FILE="$LOG_DIR/memory-cron.log"
mkdir -p "$LOG_DIR" "$ARCHIVE_DIR"
log() { echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] [memory-rotate] $*" >> "$LOG_FILE" 2>/dev/null || true; }

[ -f "$MEMORY" ] || { log "missing"; exit 0; }
SIZE=$(wc -c < "$MEMORY" | tr -d ' ')
[ "$SIZE" -le 5120 ] && { log "ok (${SIZE}B)"; exit 0; }

ARCHIVE_FILE="$ARCHIVE_DIR/$(date -u +%Y-%m).md"
python3 - "$MEMORY" "$ARCHIVE_FILE" 20 <<'PY'
import sys
from pathlib import Path
mem, arc, head = Path(sys.argv[1]), Path(sys.argv[2]), int(sys.argv[3])
lines = mem.read_text(encoding='utf-8').splitlines(keepends=True)
if len(lines) <= head: sys.exit(0)
tail = lines[head:]
with arc.open('a', encoding='utf-8') as f:
    f.write(f"\n---\n(rotated from MEMORY.md into {arc.name})\n")
    f.writelines(tail)
mem.write_text(''.join(lines[:head]).rstrip() + '\n', encoding='utf-8')
print(f"archived {len(tail)} lines")
PY

log "memory-rotate complete"
```

## 3.5 `ov-session-sync.sh` (опционально, требует OpenViking)

```bash
#!/usr/bin/env bash
# ov-session-sync.sh -- push hot+warm memory into OpenViking for semantic recall.
# No-op if OPENVIKING_URL/KEY/ACCOUNT not set in ~/agent/.env
set -euo pipefail

AGENT_WS="${AGENT_WS:-$HOME/agent/.claude}"
ENV_FILE="$HOME/agent/.env"
RECENT="$AGENT_WS/core/hot/recent.md"
DECISIONS="$AGENT_WS/core/warm/decisions.md"
LOG_FILE="$HOME/agent/logs/memory-cron.log"
mkdir -p "$(dirname "$LOG_FILE")"
log() { echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] [ov-session-sync] $*" >> "$LOG_FILE" 2>/dev/null || true; }

# Whitelist-parse 3 specific env keys (no `source` to avoid command execution).
if [ -f "$ENV_FILE" ]; then
    while IFS= read -r line || [ -n "$line" ]; do
        case "$line" in ''|\#*) continue;; esac
        key="${line%%=*}"; val="${line#*=}"
        case "$key" in
            OPENVIKING_URL|OPENVIKING_KEY|OPENVIKING_ACCOUNT) ;;
            *) continue;;
        esac
        case "$val" in *\`*|*\$*) continue;; esac
        # strip surrounding quote pair
        if [ "${val:0:1}" = '"' ] && [ "${val: -1}" = '"' ]; then val="${val:1:${#val}-2}"; fi
        export "$key=$val"
    done < "$ENV_FILE"
fi

[ -z "${OPENVIKING_URL:-}" ] && { log "OpenViking not configured -- skip"; exit 0; }
[ -z "${OPENVIKING_KEY:-}" ] && { log "no key"; exit 0; }
[ -z "${OPENVIKING_ACCOUNT:-}" ] && { log "no account"; exit 0; }

sync() {
    local f="$1" cat="$2"
    [ -f "$f" ] || return 0
    local body
    body=$(python3 -c 'import json,sys; print(json.dumps({"category":sys.argv[2],"text":open(sys.argv[1],encoding="utf-8").read()}))' "$f" "$cat")
    curl -fsS -m 30 -X POST "${OPENVIKING_URL%/}/api/v1/capture" \
        -H "X-API-Key: ${OPENVIKING_KEY}" \
        -H "X-OpenViking-Account: ${OPENVIKING_ACCOUNT}" \
        -H "Content-Type: application/json" \
        -d "$body" >/dev/null 2>&1 && log "synced ${cat}" || log "fail ${cat}"
}

sync "$RECENT" "hot"
sync "$DECISIONS" "warm"
log "complete"
```

---

# 4. CRONTAB

Запиши в `crontab -e` оператора:

```cron
# Memory rotation cron (Jarvis-style agent)
30 04 * * * AGENT_WS=$HOME/agent/.claude $HOME/agent/scripts/rotate-warm.sh
00 05 * * * AGENT_WS=$HOME/agent/.claude $HOME/agent/scripts/trim-hot.sh
00 06 * * * AGENT_WS=$HOME/agent/.claude $HOME/agent/scripts/compress-warm.sh
30 06 * * * AGENT_WS=$HOME/agent/.claude $HOME/agent/scripts/ov-session-sync.sh
00 21 * * * AGENT_WS=$HOME/agent/.claude $HOME/agent/scripts/memory-rotate.sh
```

После записи -- `chmod +x ~/agent/scripts/*.sh`.

---

# 5. SETTINGS.LOCAL.JSON (`~/agent/.claude/settings.local.json`)

Локальные permission'ы (не коммитятся, для конкретной машины):

```json
{
  "permissions": {
    "allow": [
      "Edit($HOME/agent/.claude/core/USER.md)",
      "Edit($HOME/agent/.claude/core/MEMORY.md)",
      "Write($HOME/agent/.claude/core/USER.md)",
      "Write($HOME/agent/.claude/core/MEMORY.md)"
    ]
  }
}
```

---

# 6. .ENV ПРИМЕР (`~/agent/.env`)

Только если планируется OpenViking. Иначе можно не создавать.

```bash
# OpenViking (optional)
OPENVIKING_URL=http://127.0.0.1:1933
OPENVIKING_KEY=<your-api-key>
OPENVIKING_ACCOUNT=<your-account-name>
```

`chmod 600 ~/agent/.env`.

---

# 7. ФИНАЛЬНАЯ ПРОВЕРКА

- [ ] `ls ~/agent/.claude/core/` -- AGENTS.md и TOOLS.md есть
- [ ] `ls ~/agent/scripts/` -- 5 скриптов с правом x
- [ ] `crontab -l` -- 5 cron-задач
- [ ] `bash ~/agent/scripts/rotate-warm.sh` -- запускается без ошибок (на пустых файлах ничего не делает)
- [ ] `tail ~/agent/logs/memory-cron.log` -- появляется лог-строка
- [ ] `cat ~/agent/.claude/core/AGENTS.md | head -3` -- видно header

После Промпта #2 -- агент полностью функционален в shell-режиме. Если
нужен Telegram-чат -- запускай Промпт #3 (Telegram-шлюз).
